#ifndef IPC_THREADS_H
#define IPC_THREADS_H

#include "common.h"

/*
 * IPC Worker Threads — CO-6 integrated into the IPC workflow.
 *
 * This module provides:
 *   - A thread-safe message queue for received IPC messages
 *   - Worker threads that process actual messages from pipe/FIFO
 *   - Mutex-protected shared IPC statistics
 *
 * APIs used:
 *   pthread_create(), pthread_join()
 *   pthread_mutex_lock(), pthread_mutex_unlock()
 */

#define WORKER_THREADS 3

/* Thread-safe message queue */
typedef struct {
    char **messages;
    size_t count;
    size_t capacity;
    size_t next_index;
    pthread_mutex_t mutex;
} MessageQueue;

/* Shared IPC statistics (protected by mutex) */
typedef struct {
    pthread_mutex_t mutex;
    long messages_received;
    long messages_processed;
    long bytes_processed;
} ipc_stats_t;

/* Initialize the message queue */
void mq_init(MessageQueue *mq);

/* Destroy the message queue and free all memory */
void mq_destroy(MessageQueue *mq);

/* Add a message to the queue (thread-safe) */
void mq_push(MessageQueue *mq, const char *msg, size_t len);

/* Get the next message from the queue (thread-safe) */
/* Returns 1 if a message was retrieved, 0 if queue is empty */
int mq_pop(MessageQueue *mq, char **msg, size_t *len);

/* Initialize shared IPC statistics */
void ipc_stats_init(ipc_stats_t *s);

/* Destroy shared IPC statistics */
void ipc_stats_destroy(ipc_stats_t *s);

/* Record a processed message (thread-safe) */
void ipc_stats_record(ipc_stats_t *s, size_t bytes);

/* Print shared IPC statistics (thread-safe) */
void ipc_stats_print(ipc_stats_t *s);

/* Worker thread function */
void *worker_thread(void *arg);

/* Run the worker threads on the message queue */
/* Returns after all threads have joined */
void run_workers(MessageQueue *mq, ipc_stats_t *s, int num_threads);

#endif /* IPC_THREADS_H */
