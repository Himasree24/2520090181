#include "ipc_threads.h"

/* ============================================================================
 * MESSAGE QUEUE
 * ============================================================================ */

void mq_init(MessageQueue *mq)
{
    mq->capacity = 16;
    mq->count = 0;
    mq->next_index = 0;
    mq->messages = malloc(mq->capacity * sizeof(char *));
    if (mq->messages == NULL) {
        perror("malloc");
        exit(1);
    }
    if (pthread_mutex_init(&mq->mutex, NULL) != 0) {
        perror("pthread_mutex_init");
        exit(1);
    }
}

void mq_destroy(MessageQueue *mq)
{
    for (size_t i = 0; i < mq->count; i++) {
        free(mq->messages[i]);
    }
    free(mq->messages);
    pthread_mutex_destroy(&mq->mutex);
}

void mq_push(MessageQueue *mq, const char *msg, size_t len)
{
    pthread_mutex_lock(&mq->mutex);

    if (mq->count >= mq->capacity) {
        mq->capacity *= 2;
        mq->messages = realloc(mq->messages, mq->capacity * sizeof(char *));
        if (mq->messages == NULL) {
            perror("realloc");
            pthread_mutex_unlock(&mq->mutex);
            exit(1);
        }
    }

    mq->messages[mq->count] = malloc(len + 1);
    if (mq->messages[mq->count] == NULL) {
        perror("malloc");
        pthread_mutex_unlock(&mq->mutex);
        exit(1);
    }
    memcpy(mq->messages[mq->count], msg, len);
    mq->messages[mq->count][len] = '\0';
    mq->count++;

    pthread_mutex_unlock(&mq->mutex);
}

int mq_pop(MessageQueue *mq, char **msg, size_t *len)
{
    pthread_mutex_lock(&mq->mutex);

    if (mq->next_index >= mq->count) {
        pthread_mutex_unlock(&mq->mutex);
        return 0;
    }

    *msg = mq->messages[mq->next_index];
    *len = strlen(*msg);
    mq->next_index++;

    pthread_mutex_unlock(&mq->mutex);
    return 1;
}

/* ============================================================================
 * SHARED IPC STATISTICS
 * ============================================================================ */

void ipc_stats_init(ipc_stats_t *s)
{
    s->messages_received = 0;
    s->messages_processed = 0;
    s->bytes_processed = 0;
    if (pthread_mutex_init(&s->mutex, NULL) != 0) {
        perror("pthread_mutex_init");
        exit(1);
    }
}

void ipc_stats_destroy(ipc_stats_t *s)
{
    pthread_mutex_destroy(&s->mutex);
}

void ipc_stats_record(ipc_stats_t *s, size_t bytes)
{
    pthread_mutex_lock(&s->mutex);
    s->messages_processed++;
    s->bytes_processed += bytes;
    pthread_mutex_unlock(&s->mutex);
}

void ipc_stats_print(ipc_stats_t *s)
{
    pthread_mutex_lock(&s->mutex);
    printf("\n  +----------------------------------------+\n");
    printf("  |     IPC PROCESSING STATISTICS         |\n");
    printf("  +----------------------------------------+\n");
    printf("  | Messages received:  %ld\n", s->messages_received);
    printf("  | Messages processed:  %ld\n", s->messages_processed);
    printf("  | Bytes processed:     %ld\n", s->bytes_processed);
    printf("  +----------------------------------------+\n");
    pthread_mutex_unlock(&s->mutex);
}

/* ============================================================================
 * WORKER THREAD
 * ============================================================================ */

typedef struct {
    MessageQueue *mq;
    ipc_stats_t *stats;
    int thread_id;
} worker_arg_t;

void *worker_thread(void *arg)
{
    worker_arg_t *warg = (worker_arg_t *)arg;
    char *msg = NULL;
    size_t len = 0;

    while (mq_pop(warg->mq, &msg, &len)) {
        printf("  [Thread %d] Processing message: \"%s\" (%zu bytes)\n",
               warg->thread_id, msg, len);
        ipc_stats_record(warg->stats, len);
    }

    printf("  [Thread %d] No more messages. Exiting.\n", warg->thread_id);

    free(warg);
    return NULL;
}

/* ============================================================================
 * RUN WORKER THREADS
 * ============================================================================ */

void run_workers(MessageQueue *mq, ipc_stats_t *s, int num_threads)
{
    pthread_t threads[WORKER_THREADS];
    int i;

    printf("\n  Starting %d worker threads...\n", num_threads);

    for (i = 0; i < num_threads; i++) {
        worker_arg_t *arg = malloc(sizeof(worker_arg_t));
        if (arg == NULL) {
            perror("malloc");
            return;
        }
        arg->mq = mq;
        arg->stats = s;
        arg->thread_id = i + 1;

        if (pthread_create(&threads[i], NULL, worker_thread, arg) != 0) {
            perror("pthread_create");
            free(arg);
            return;
        }
    }

    for (i = 0; i < num_threads; i++) {
        if (pthread_join(threads[i], NULL) != 0) {
            perror("pthread_join");
        }
    }

    printf("  pthread_join(): all worker threads completed\n");
    printf("  Mutex synchronization: PASSED\n");
}
